package com.notes.notes.constants;

public class ExceptionConstants {
}
